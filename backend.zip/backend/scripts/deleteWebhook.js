// Run with `npm run delete-webhook` — useful when switching back to local testing.
require("dotenv").config();
const tg = require("../lib/telegram");

tg.deleteWebhook()
  .then(() => console.log("✅ Webhook removed."))
  .catch((err) => {
    console.error("❌ Failed:", err.message);
    process.exit(1);
  });
