# Offline Activation — Backend

Handles real Telegram Stars payments for the Mini App: creates invoices, confirms
payment, and automatically sends the buyer their purchased account.

**What this does NOT do:** store your BOT_TOKEN anywhere but your own `.env` /
hosting provider's environment variables. It is never sent to the frontend,
never logged, never visible to me or anyone else.

---

## How it fits together

```
Mini App (GitHub Pages)  →  POST /api/create-invoice  →  this backend
                                                              │
                                                    createInvoiceLink (Telegram)
                                                              │
Mini App  ←──────────── invoice link ─────────────────────────┘
   │
   openInvoice() — user pays with Stars inside Telegram
   │
Telegram  →  POST /webhook/<secret>  →  this backend  →  sends account details to user
```

---

## 1. Local setup

```bash
cd backend
npm install
cp .env.example .env
```

Open `.env` and fill in:

- `BOT_TOKEN` — from **@BotFather** → `/mybots` → your bot → **API Token**
- `WEBHOOK_SECRET` — make one up, e.g. run:
  ```bash
  node -e "console.log(require('crypto').randomBytes(24).toString('hex'))"
  ```
- `ALLOWED_ORIGINS` — your GitHub Pages URL, e.g. `https://your-username.github.io`

Start it:

```bash
npm start
```

You should see `Offline Activation backend listening on port 3000`.

Visit `http://localhost:3000/api/health` in a browser — `{"ok":true,...}` means it's running.

---

## 2. Fill in real Steam account credentials

Open `data/catalog.json`. Each game has:

```json
"delivery": {
  "steamLogin": "REPLACE_ME",
  "steamPassword": "REPLACE_ME",
  "note": "..."
}
```

Replace `REPLACE_ME` with the real login/password for games you actually have
stock for. Games still showing `REPLACE_ME` will tell the buyer "our team
will send your account details shortly" instead of a broken message — so
it's safe to leave some unfinished, but obviously fill in what you're
actually selling before taking real payments for it.

---

## 3. Deploy so Telegram can reach it (Render, free tier)

Telegram needs a public **HTTPS** URL to send payment confirmations to —
`localhost` doesn't work for real payments.

1. Push the `backend` folder to its own GitHub repository (same process as
   before: create a repo, e.g. `offline-activation-backend`, then **Add
   file → Upload files** and drag in everything from the `backend` folder
   — **except** `.env`, which should never leave your computer; `.gitignore`
   already excludes it if you use `git push` instead).
2. Go to **render.com** → sign up / log in (GitHub login is easiest) →
   **New → Web Service**.
3. Connect the repository you just created.
4. Settings:
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
5. Under **Environment**, add the same variables from your `.env`:
   `BOT_TOKEN`, `WEBHOOK_SECRET`, `ALLOWED_ORIGINS` (set this to your real
   GitHub Pages URL now, not `*`).
6. **Create Web Service**. Wait for the first deploy to finish — Render gives
   you a URL like `https://offline-activation-backend.onrender.com`.

(Railway and Fly.io work the same way if you prefer those — same env vars,
same build/start commands.)

---

## 4. Tell Telegram where the webhook is

From your own computer, with your **local** `.env` filled in with the same
`BOT_TOKEN` and `WEBHOOK_SECRET` you set on Render:

```bash
npm run set-webhook -- https://offline-activation-backend.onrender.com
```

You should see `✅ Webhook set to: .../webhook/<your-secret>`.

Check it worked any time with:

```bash
npm run webhook-info
```

---

## 5. Point the Mini App at this backend

In the frontend's `index.html`, find (near the top of the `<script>` block):

```js
apiBaseUrl: "https://api.offlineactivation.example/v1",
```

Replace it with your real Render URL:

```js
apiBaseUrl: "https://offline-activation-backend.onrender.com",
```

Re-upload `index.html` to your frontend GitHub repo (same as before). Payments
will now actually run through this backend when the Mini App is opened inside
real Telegram.

---

## Testing

- Opening the Mini App **outside** real Telegram (plain browser preview) —
  Pay falls back to the old simulated flow automatically, since
  `Telegram.WebApp.openInvoice` doesn't exist there. That's expected, not a bug.
- Inside real Telegram: tap **PAY** with something in the cart → Telegram's
  native payment sheet should open, priced in ⭐ Stars → completing it should
  trigger `successful_payment` → you'll get a message from your bot with the
  account details within a couple of seconds.
- `npm run webhook-info` is the first place to check if payments aren't
  arriving — look at `last_error_message` if present.

---

## Balance top-ups (PAY button → "Top up balance")

Tapping the glowing **PAY** button in the app no longer checks out the cart
directly — it opens a sheet where the person picks an exact amount and one
of two ways to add it to their in-app balance:

### Option 1 — Telegram Stars (fully working, tested)

`POST /api/create-topup-invoice` — same `createInvoiceLink` mechanism as
regular orders, just for a chosen Stars amount instead of cart contents. On
`successful_payment`, the webhook credits `data/balances.json` for that user
and messages them their new balance. No extra setup needed beyond `BOT_TOKEN`.

### Option 2 — Crypto via Telegram Wallet (needs your own setup, unverified)

This uses **Wallet Pay** (`pay.wallet.tg`), Telegram's official crypto
payment product — a completely separate product from the Bot API, with its
own merchant account and API key.

⚠️ **Before this can accept real money:**

1. Create a merchant account at **pay.wallet.tg** and get an API key.
2. Set `WALLET_PAY_API_KEY` and `PUBLIC_URL` in `.env`.
3. Open `lib/walletpay.js` — I wrote it against my general knowledge of
   Wallet Pay's REST API shape, but **have not tested it against a live
   account**. Compare the request/response field names and the webhook
   signature method against Wallet Pay's current docs and fix anything
   that's drifted before going live.
4. Send yourself one small real payment end-to-end as a final check.

Until `WALLET_PAY_API_KEY` is set, the crypto option fails with a clear
"not configured yet" error instead of doing something silently wrong — the
Stars top-up path is completely unaffected either way.

### What "balance" does today

Topping up credits `data/balances.json` and messages the user their new
total. **Spending that balance on a purchase is not wired up in this build**
— right now, buying a game (via the Cart's "Checkout" button) still creates
its own separate Stars invoice, same as before. Deducting from balance
instead is a natural next step if you want it — ask and it can be added.

---

## A note on free hosting tiers

Free tiers on Render (and similar) "spin down" after ~15 minutes of no
traffic and take a few seconds to wake back up on the next request — the
very first `Pay` tap after a quiet period may feel slightly slow. Fine for
testing and small stores; upgrade to a paid tier once you have real, steady
traffic.
